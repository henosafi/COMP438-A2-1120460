package com.example.owners.calculater;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public TextView txt;
    public String text="0",op;
    public int answer;
    public String term1,term2,output;
    int negative_counter=0;
    public String memoValue="0";
    public Button num0,num1,num2,num3, num4,num5, num6, num7, num8, num9;
    public Button clear,equal,back,negative;
    public Button plus, minus,div,multi;
    public Button memoS,memoC,memoR;
    private int counter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        txt=(TextView)findViewById(R.id.text);
        num0=(Button)findViewById(R.id.num0);
        num1=(Button)findViewById(R.id.num1);
        num2=(Button)findViewById(R.id.num2);
        num3=(Button)findViewById(R.id.num3);
        num4=(Button)findViewById(R.id.num4);
        num5=(Button)findViewById(R.id.num5);
        num6=(Button)findViewById(R.id.num6);
        num7=(Button)findViewById(R.id.num7);
        num8=(Button)findViewById(R.id.num8);
        num9=(Button)findViewById(R.id.num9);
        memoC=(Button)findViewById(R.id.mc);
        memoR=(Button)findViewById(R.id.mr);
        memoS=(Button)findViewById(R.id.ms);
        clear=(Button)findViewById(R.id.clear);
        negative=(Button)findViewById(R.id.nig);
        back=(Button)findViewById(R.id.back);
        plus=(Button)findViewById(R.id.add);
        multi=(Button)findViewById(R.id.mul);
        minus=(Button)findViewById(R.id.min);
        div=(Button)findViewById(R.id.div);
        equal=(Button)findViewById(R.id.equal);
        txt.setText("0");

        num0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(text == "0")) {
                    text = text + "0";
                }
                else
                    if(counter==1)
                        text="0";
                txt.setText(text);
            }
        });


        num1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="1";
                else
                    text=text+"1";
                txt.setText(text);
            }
        });

        num2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="2";
                else
                text=text+"2";
                txt.setText(text);
            }
        });

        num3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="3";
                else
                text=text+"3";
                txt.setText(text);
            }
        });

        num4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="4";
                else
                text=text+"4";
                txt.setText(text);
            }
        });

        num5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="5";
                else
                text=text+"5";
                txt.setText(text);
            }
        });

        num6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="6";
                else
                text=text+"6";
                txt.setText(text);
            }
        });

        num7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="7";
                else
                text=text+"7";
                txt.setText(text);
            }
        });

        num8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="8";
                else
                text=text+"8";
                txt.setText(text);
            }
        });

        num9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text=="0"||counter==1)
                    text="9";
                else
                text=text+"9";
                txt.setText(text);
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text="0";
                txt.setText(text);
            }
        });

        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(isOperation(text.charAt(text.length() - 1)))
                    text = text.replace(text.charAt(text.length()-1),'+');
               else
                    if(text.contains("+")||text.contains("-")||text.contains("x")||text.contains("÷")) {
                         getOutput();
                        text=text+"+";
                    }
                    else
                        text=text+"+";

                txt.setText(text);

            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isOperation(text.charAt(text.length() - 1)))
                    text = text.replace(text.charAt(text.length()-1),'-');
                else
                if(text.contains("+")||text.contains("-")||text.contains("x")||text.contains("÷")) {
                     getOutput();
                    text=text+"-";
                }
                else
                text=text+"-";
                txt.setText(text);

            }
        });

        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isOperation(text.charAt(text.length() - 1)))
                    text = text.replace(text.charAt(text.length()-1),'x');
                else
                if(text.contains("+")||text.contains("-")||text.contains("x")||text.contains("÷")) {
                    getOutput();
                    text=text+"x";
                }
                else
                text=text+"x";
                txt.setText(text);

            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isOperation(text.charAt(text.length() - 1)))
                    text = text.replace(text.charAt(text.length()-1),'÷');
                else
                if(text.contains("+")||text.contains("-")||text.contains("x")||text.contains("÷")) {
                    getOutput();
                    text=text+"÷";
                }
                else
                text=text+"÷";
                txt.setText(text);

            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isOperation(text.charAt(text.length() - 1)))
                       getOutput();
                        counter=1;

                    }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    if(text.length()>1)
                        text=text.substring(0,text.length()-1);
                else
                    text="0";
                txt.setText((text));

            }
        });


        memoS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isOperation(text.charAt(text.length()-1)))
                    memoValue=(text.substring(0,text.length()-1));
                else
                for (int i = 1; i < text.length(); i++)
                    if (isOperation(text.charAt(i)))
                        memoValue = text.substring(i+1,text.length());
                message();
                text="0";
                txt.setText(text);

            }
        });

        memoR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text.length()==1)
                    text=memoValue;
                else
                    if(isOperation(text.charAt(text.length()-1)))
                    text=text+memoValue;
                    else
                    text=memoValue;

                txt.setText(text);
            }
        });

        memoC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                memoValue="0";
            }
        });

        negative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(text.charAt(0)!='0'){
                    if(negative_counter%2==0){
                        text = '-' + text;
                        txt.setText(text);negative_counter++;}
                    else{
                        text = text.substring(1,text.length());
                        txt.setText(text);negative_counter++;
                    }

                }
            }
        });

    }

    private void message() {
        Toast.makeText(this, memoValue + " saved in the memory", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
       public boolean isOperation(Character last_char){
            if ((last_char=='x')||(last_char=='-')||(last_char=='+')||(last_char=='÷'))
                return true;
            return false;
        }
   public boolean IsDigit(String lastchar){
       int  number=Integer.getInteger(lastchar);
       if((number>='0'&&number<='9'))
           return true;
       return false;
   }


    private void getOutput() {
        text = text.trim();
        output=text;
        for (int i = 1; i < text.length(); i++) {
            if (isOperation(text.charAt(i))) {
                term1 = text.substring(0, i);
                text=output;
                term2 = text.substring(i + 1, text.length());
                text=output;
                answer= calculateIt(Integer.parseInt(term1),text.charAt(i),Integer.parseInt(term2));
                txt.setText(String.valueOf(answer));
                text = String.valueOf(answer);
                break;
            }
        }

    }
    public int calculateIt(int x,char op,int y){
        double inf = Double.POSITIVE_INFINITY;
        switch(op){
            case'+':return x+y;
            case'-':return x-y;
            case'x':return x*y;
            case'÷':{
                if(y!=0)
                    return x/y;

            }
            default:  return (int)inf;


        }}

}
